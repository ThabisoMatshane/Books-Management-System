using NUnit.Framework;
using BooksManagementSystem;
using BooksManagementSystem.BusinessLogic;
using BooksManagementSystem.Models;
using System;
using System.Text;
using System.IO;

namespace BooksManagement_nUnitTests
{
    public class UnitTests
    {
        [SetUp]
        public void Setup()
        {

        }

        private static string CaptureConsoleOutput(Action action)
        {
            var stringBuilder = new StringBuilder();
            var stringWriter = new StringWriter(stringBuilder);
            Console.SetOut(stringWriter);

            action.Invoke();

            Console.SetOut(new StreamWriter(Console.OpenStandardOutput()));
            return stringBuilder.ToString().TrimEnd();
        }

        [Test]
        public void AddBook_AddsBookToList()
        {
            // Arrange
            var library = new Library();

            var bookToAdd = new Book(1, "Test Book", "Test Author", 2022, true);

            // Act
            library.AddBook(bookToAdd);

            // Assert
            var addedBook = library.GetBook(bookToAdd.BookID);
            Assert.IsNotNull(addedBook, "The book should have been added to the library.");
            Assert.AreEqual(bookToAdd.Title, addedBook.Title, "The book title should match the added book title.");
        }

        [Test]
        public void AddBook_BookWithSameIDAlreadyExists_ReturnsErrorMessage()
        {
            // Arrange
            var library = new Library();
            var bookToAdd = new Book(1, "Test Book", "Test Author", 2022, true);

            // Add the book to the library
            library.AddBook(bookToAdd);

            // Act
            var result = CaptureConsoleOutput(() => library.AddBook(bookToAdd));

            // Assert
            Assert.IsTrue(result.Contains("Book with the same ID already exists."), "An error message should have been printed.");
        }

        [Test]
        public void RemoveBook_RemovesBookFromList()
        {
            // Arrange
            var library = new Library();
            var bookToAdd = new Book(1, "Test Book", "Test Author", 2022, true);

            // Add the book to the library
            library.AddBook(bookToAdd);

            // Act
            library.RemoveBook(bookToAdd.BookID);

            // Assert
            var removedBook = library.GetBook(bookToAdd.BookID);
            Assert.IsNull(removedBook, "The book should have been removed from the library.");
        }

        [Test]
        public void RemoveBook_BookNotFound_ReturnsErrorMessage()
        {
            // Arrange
            var library = new Library();
            var bookToRemoveID = 1;

            // Act
            var result = CaptureConsoleOutput(() => library.RemoveBook(bookToRemoveID));

            // Assert
            Assert.IsTrue(result.Contains("Book not found."), "An error message should have been printed.");
        }

        [Test]
        public void UpdateBook_UpdatesBookInformation()
        {
            // Arrange
            var library = new Library();
            var bookToUpdate = new Book(1, "Test Book", "Test Author", 2022, true);

            // Add the book to the library
            library.AddBook(bookToUpdate);

            // Update the book information
            var updatedBook = new Book(bookToUpdate.BookID, "Test Book", "Test Author", 2022, true);

            library.UpdateBook(bookToUpdate.BookID, updatedBook);

            // Assert
            var savedBook = library.GetBook(bookToUpdate.BookID);
            Assert.IsNotNull(savedBook, "The book should have beenupdated and retrieved successfully");
            Assert.AreEqual(updatedBook.Title, savedBook.Title, "The book title should have been updated");
            Assert.AreEqual(updatedBook.Author, savedBook.Author, "The book author should have been updated");
            Assert.AreEqual(updatedBook.PublicationYear, savedBook.PublicationYear, "The book publication year should have been updated");
            Assert.AreEqual(updatedBook.IsAvailable, savedBook.IsAvailable, "The book availability should have been updated");
        }

        [Test]
        public void DeleteBook_RemovesBookFromLibrary()
        {
            // Arrange
            var library = new Library();
            var bookToDelete = new Book(1, "Test Book", "Test Author", 2022, true);

            // Add the book to the library
            library.AddBook(bookToDelete);

            // Assert that the book was added successfully
            var savedBook = library.GetBook(bookToDelete.BookID);
            Assert.IsNotNull(savedBook, "The book should have been added to the library");

            // Act
            library.RemoveBook(bookToDelete.BookID);

            // Assert that the book was deleted successfully
            savedBook = library.GetBook(bookToDelete.BookID);
            Assert.IsNull(savedBook, "The book should have been removed from the library");
        }

    }
}