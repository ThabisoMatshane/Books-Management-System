﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BooksManagementSystem.Models
{
    internal class Global
    {
        //Data Location Method
        public string DataLocation()
        {
            string filePath = @"C:\Users\Thabiso.matshane\source\repos\BooksManagementSystem\Data\BooksData.json";

            return filePath;
        }
    }
}
