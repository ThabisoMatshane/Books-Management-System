﻿using System;
using System.Web;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace BooksManagementSystem.Models
{
    internal class Global
    {
        //Data Location Method

        public string DataLocation()
        {
            string fileName = "BooksData.json";
            string baseDirectory = Directory.GetParent(Directory.GetCurrentDirectory()).Parent.Parent.FullName;
            string directoryPath = Path.Combine(baseDirectory, "Data", fileName);

            return directoryPath;

        }
    }
}
