﻿using BooksManagementSystem.Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace BooksManagementSystem.BusinessLogic
{
    public class Library
    {
        public readonly string filePath;

        // The list of books in the library
        private List<Book> Books;
        public Library()
        {
            // Load the data from the data file
            LoadData();

            // Initialize the Books list
            Books = new List<Book>();

            // Save data to file
            //string projectDirectoryPath = Path.GetDirectoryName(Path.GetDirectoryName(Directory.GetCurrentDirectory()));
            //filePath = Path.Combine("BooksData.json");
            Global global = new Global();
            filePath = global.DataLocation();
            //filePath.Replace("bin\"", "");
        }

        // Adds a book to the library
        public void AddBook(Book book)
        {
            // Check if the book already exists in the library
            if (GetBook(book.BookID) != null)
            {
                Console.WriteLine("Book with the same ID already exists.");
                return;
            }

            // Add the book to the list of books
            Books.Add(book);

            // Save the data to the data file
            SaveData();

            // Print a success message
            Console.WriteLine("Book added successfully.");
        }

        // Removes a book from the library
        public void RemoveBook(int bookID)
        {
            // Get the book to remove
            Book bookToRemove = GetBook(bookID);

            // Check if the book exists
            if (bookToRemove == null)
            {
                Console.WriteLine("Book not found.");
                return;
            }

            // Remove the book from the list of books
            Books.Remove(bookToRemove);

            // Save the data to the data file
            SaveData();

            // Print a success message
            Console.WriteLine("Book removed successfully.");
        }

        // Updates a book in the library
        public void UpdateBook(int bookID, Book updatedBook)
        {

            // Read the data from the JSON file
            string jsonData = File.ReadAllText(filePath);
            List<Book> books = JsonConvert.DeserializeObject<List<Book>>(jsonData);

            // Find the book to update
            Book bookToUpdate = books.Find(b => b.BookID == bookID);

            // Check if the book exists
            if (bookToUpdate == null)
            {
                Console.WriteLine("Book not found.");
                return;
            }


            // Update the book information
            bookToUpdate.Title = updatedBook.Title;
            bookToUpdate.Author = updatedBook.Author;
            bookToUpdate.PublicationYear = updatedBook.PublicationYear;
            bookToUpdate.IsAvailable = updatedBook.IsAvailable;

            // Write the updated data back to the file
            string updatedData = JsonConvert.SerializeObject(books, Formatting.Indented);
            File.WriteAllText(filePath, updatedData);

            // Print a success message
            Console.WriteLine("Book updated successfully.");
        }

        // Gets a book by its ID
        public Book GetBook(int bookID)
        {
            foreach (Book book in Books)
            {
                if (book.BookID == bookID)
                {
                    return book;
                }
            }
            return null;
        }

        // Gets a list of available books in the library
        public List<Book> GetAvailableBooks()
        {
            LoadData(); // load the data from the JSON file
            List<Book> availableBooks = new List<Book>();


            foreach (Book book in Books)
            {
                if (book.IsAvailable)
                {
                    availableBooks.Add(book);
                }
            }
            return availableBooks;
        }

        // Searches for books in the library by keyword
        public List<Book> SearchBooks(string keyword)
        {
            if (string.IsNullOrEmpty(keyword))
            {
                throw new ArgumentException("Keyword cannot be null or empty.", nameof(keyword));
            }

            List<Book> matchingBooks = new List<Book>();
            foreach (Book book in Books)
            {
                if (book.Title.Contains(keyword, StringComparison.OrdinalIgnoreCase) || book.Author.Contains(keyword, StringComparison.OrdinalIgnoreCase))
                {
                    matchingBooks.Add(book);
                }
            }
            return matchingBooks;
        }

        // Loads the data from the data file
        private void LoadData()
        {
            // This code checks if the data file exists and loads the data from the file if it does.

            // The file path is checked to see if it exists.
            if (File.Exists(filePath))
            {
                // If the file exists, the data is loaded from the file.
                try
                {
                    // The data is read from the file.
                    string jsonData = File.ReadAllText(filePath);

                    // The data is deserialized from JSON.
                    Books = JsonConvert.DeserializeObject<List<Book>>(jsonData);
                }
                catch (Exception ex)
                {
                    // If an exception is thrown, it is caught and displayed to the user.
                    Console.WriteLine($"Error loading data from file: {ex.Message}");

                    // The list of books is cleared.
                    Books = new List<Book>();
                }
            }
            else
            {
                // If the file does not exist, the list of books is cleared.
                Books = new List<Book>();
            }

        }

        //Write file inside the Data Folder
        private void SaveData()
        {
            try
            {
                // This code tries to write the list of books to a file.
                // The list of books is serialized to JSON.
                string jsonData = JsonConvert.SerializeObject(Books);

                // The JSON data is written to a file.
                File.WriteAllText(filePath, jsonData);
            }
            catch (Exception ex)
            {
                // If an exception is thrown, it is caught and displayed to the user.
                Console.WriteLine($"Error saving data to file: {ex.Message}");
            }
        }
    }
}
