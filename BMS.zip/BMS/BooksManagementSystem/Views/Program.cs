﻿using BooksManagementSystem.BusinessLogic;
using BooksManagementSystem.Models;
using Newtonsoft.Json;

public class Program
{
    public static void Main()
    {
        // Create a new instance of the Library and Global classes, and get the file path to the data file
        Library library = new Library();
        Global global = new Global();
        string filePath = global.DataLocation();

        // Set a flag to keep track of whether the user wants to exit the application
        bool exitRequested = false;

        // Loop until the user requests to exit the application
        while (!exitRequested)
        {
            // Display the main menu and get the user's choice
            Console.WriteLine("Welcome to the Book Management System");
            Console.WriteLine("Please select an option:");
            Console.WriteLine("1. Add a new book");
            Console.WriteLine("2. Remove a book by ID");
            Console.WriteLine("3. Update book information");
            Console.WriteLine("4. Search for a book");
            Console.WriteLine("5. List all available books");
            Console.WriteLine("6. Exit the application");

            int choice = GetMenuChoice();

            // Handle the user's choice based on the selected menu item
            switch (choice)
            {
                case 1:
                    // Add a new book to the library
                    AddNewBook(library);
                    break;
                case 2:
                    // Remove a book from the library by ID
                    RemoveBookByID(library);
                    break;
                case 3:
                    // Update information for an existing book
                    UpdateBookInformation(library, filePath);
                    break;
                case 4:
                    // Search for a book in the library
                    SearchForBook(library);
                    break;
                case 5:
                    // List all available books in the library
                    ListAvailableBooks(library);
                    break;
                case 6:
                    // Set the flag to exit the application
                    exitRequested = true;
                    break;
                default:
                    // Handle an invalid menu choice
                    Console.WriteLine("Invalid choice. Please try again.");
                    break;
            }
        }

        Console.WriteLine();
    }


    // Helper method to get the user's choice from the main menu
    public static int GetMenuChoice()
    {
        Console.Write("Choice: ");
        int choice = int.Parse(Console.ReadLine());
        return choice;
    }

    //Add New Book
    public static void AddNewBook(Library library)
    {
        // Generate a random book ID
        Random random = new Random();
        int bookID = random.Next(10000, 99999);

        // Prompt the user to enter book details
        Console.WriteLine("Adding a new book...");
        Console.WriteLine("BookID: " + bookID);
        Console.Write("Title: ");
        string title = Console.ReadLine();
        Console.Write("Author: ");
        string author = Console.ReadLine();
        Console.Write("Publication year: ");

        // Validate and parse the publication year input
        int publicationYear;
        while (true)
        {
            Console.Write("Publication year: ");
            if (int.TryParse(Console.ReadLine(), out publicationYear))
            {
                if (publicationYear >= 0 && publicationYear <= DateTime.Now.Year)
                {
                    break;
                }
                else
                {
                    Console.WriteLine("Invalid publication year. Please try again.");
                }
            }
            else
            {
                Console.WriteLine("Invalid publication year. Please try again.");
            }
        }

        Console.Write("Is available (true/false): ");

        // Validate and parse the isAvailable input
        bool isAvailable;
        while (!bool.TryParse(Console.ReadLine(), out isAvailable))
        {
            Console.WriteLine("Invalid input. Please enter either 'true' or 'false'.");
        }

        // Create a new Book object and add it to the Library
        Book bookToAdd = new Book(bookID, title, author, publicationYear, isAvailable);
        library.AddBook(bookToAdd);

        // Print a success message
        Console.WriteLine("Book added.");

    }

    //Remove Book By ID
    public static void RemoveBookByID(Library library)
    {
        Console.WriteLine("Removing a book...");

        // Display all books in the library
        List<Book> books = library.GetAvailableBooks();
        Console.WriteLine("All books in the library:");
        foreach (Book book in books)
        {
            Console.WriteLine($"ID: {book.BookID}, Title: {book.Title}, Author: {book.Author}, Publication Year: {book.PublicationYear}");
        }

        Console.Write("BookID: ");
        int bookID = int.Parse(Console.ReadLine());

        library.RemoveBook(bookID);

        Console.WriteLine("Book removed.");
    }

    //Update Book
    public static void UpdateBookInformation(Library library, string filePath)
    {
        // This code updates a book in a library.

        // First, the available books are displayed to the user.
        Console.WriteLine("Updating a book...");
        Console.WriteLine("Available books:");
        List<Book> availableBooks = library.GetAvailableBooks();

        // The books are then deserialized from a JSON file.
        string jsonData = File.ReadAllText(filePath);
        List<Book> books = JsonConvert.DeserializeObject<List<Book>>(jsonData);

        // If there are no available books, the program exits.
        if (availableBooks.Count == 0)
        {
            Console.WriteLine("No available books to update.");
            return;
        }

        // Each book is then displayed to the user.
        foreach (Book book in availableBooks)
        {
            Console.WriteLine($"ID: {book.BookID}, Title: {book.Title}, Author: {book.Author}, Publication Year: {book.PublicationYear}");
        }

        // The user is then prompted to enter the ID of the book they want to update.
        Console.Write("Enter the ID of the book to update: ");
        int bookID = int.Parse(Console.ReadLine());

        // The book is then retrieved from the library.
        Book bookToUpdate = library.GetBook(bookID);

        // If the book is not found, the program exits.
        if (bookToUpdate == null)
        {
            Console.WriteLine("No book found with that ID.");
            return;
        }

        // The current title of the book is displayed to the user.
        Console.WriteLine($"Current title: {bookToUpdate.Title}");

        // The user is then prompted to enter a new title for the book.
        Console.Write("New title (press enter to keep current value): ");
        string newTitle = Console.ReadLine();

        // If the user enters a new title, it is set for the book.
        if (newTitle != "")
        {
            bookToUpdate.Title = newTitle;
        }

        // The current author of the book is displayed to the user.
        Console.WriteLine($"Current author: {bookToUpdate.Author}");

        // The user is then prompted to enter a new author for the book.
        Console.Write("New author (press enter to keep current value): ");
        string newAuthor = Console.ReadLine();

        // If the user enters a new author, it is set for the book.
        if (newAuthor != "")
        {
            bookToUpdate.Author = newAuthor;
        }

        // The current publication year of the book is displayed to the user.
        Console.WriteLine($"Current publication year: {bookToUpdate.PublicationYear}");

        // The user is then prompted to enter a new publication year for the book.
        Console.Write("New publication year (press enter to keep current value): ");
        string newPublicationYearString = Console.ReadLine();

        // If the user enters a new publication year, it is set for the book.
        if (newPublicationYearString != "")
        {
            int newPublicationYear = int.Parse(newPublicationYearString);
            bookToUpdate.PublicationYear = newPublicationYear;
        }

        // The updated data is then written back to the file.
        string updatedData = JsonConvert.SerializeObject(books, Formatting.Indented);
        File.WriteAllText(filePath, updatedData);

        // The book is then updated in the library.
        library.UpdateBook(bookID, bookToUpdate);

        // The user is then notified that the book was updated successfully.
        Console.WriteLine("Book updated successfully!");

    }

    //Search Book
    public static void SearchForBook(Library library)
    {
        // This code searches for books in a library.

        // The user is prompted to enter a keyword to search for.
        Console.WriteLine("Enter a keyword to search for:");
        string keyword = Console.ReadLine();

        // The library is searched for books that match the keyword.
        List<Book> results = library.SearchBooks(keyword);

        // If no books are found, the user is notified.
        if (results.Count == 0)
        {
            Console.WriteLine("No results found");
        }

        // Otherwise, the results are displayed to the user.
        else
        {
            Console.WriteLine($"Found {results.Count} results:");
            foreach (Book book in results)
            {
                Console.WriteLine($"ID: {book.BookID}, Title: {book.Title}, Author: {book.Author}, Publication Year: {book.PublicationYear}");
            }
        }

    }

    //List Books
    public static void ListAvailableBooks(Library library)
    {
        // This code lists all available books in a library.

        // The library is queried for all available books.
        List<Book> availableBooks = library.GetAvailableBooks();

        // The number of available books is displayed to the user.
        Console.WriteLine($"Available Books ({availableBooks.Count}):");

        // Each available book is displayed to the user.
        foreach (Book book in availableBooks)
        {
            Console.WriteLine($"ID: {book.BookID}, Title: {book.Title}, Author: {book.Author}, Publication Year: {book.PublicationYear}");
        }
    }
}

